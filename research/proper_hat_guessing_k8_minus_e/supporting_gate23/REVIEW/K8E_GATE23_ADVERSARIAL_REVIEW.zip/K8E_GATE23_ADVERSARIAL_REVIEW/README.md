# Independent adversarial review artifacts

Read `ADVERSARIAL_REVIEW.md` for the findings and their scope. The disposition is **ACCEPT_WITH_EXPLICIT_REPAIRS**.

The uploaded archive's SHA-256 and 153,165-byte size matched. All major general and finite claims survived independent reconstruction. The main mathematical presentation repair is to distinguish the correctly reproduced connected-core spectrum from unrestricted maxima; the latter equal `floor(m/2)` through `m=12`.

## Reproduce the independent audit

The package argument is the directory containing the original `DATA`, `MACHINE`, and `THEOREMS` subdirectories. Keep generated results outside that original package to avoid invalidating its manifest inventory.

```bash
python3 -B independent_audit.py /path/to/extracted/original/package --out ./audit_output
```

Dependencies are NumPy and SciPy; the audit was run with versions 2.3.5 and 1.17.0 respectively. The checker does not import the package's geometry or matching implementations.

## Independently verify the 2,000-rule experiment

Use the specified GCC/libstdc++ 14.2.0 setup for exact seeded-shuffle reproduction:

```bash
g++ -std=c++20 -O2 emit_seeded_rules.cpp -o emit_seeded_rules
./emit_seeded_rules 2000 > seeded_rules_2000.bin
python3 -B independent_seed_scout.py /path/to/extracted/original/package \
    seeded_rules_2000.bin --out ./audit_output
```

The generator's output is compared against every frozen bad-rule row. The separate Python checker reconstructs the graph independently and checks all matching edges, counts, and missing-view witnesses. Successful matching sizes combined with the missing views certify exact deficiencies.

The downloadable bundle omits executables, the easily regenerated binary rule stream, and bulky reproduced witness tables. It includes source, results, and comparison logs.
